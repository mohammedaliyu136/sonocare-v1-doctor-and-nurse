import 'package:doctor_v2/provider/app_provider.dart';
import 'package:doctor_v2/provider/auth_provider.dart';
import 'package:doctor_v2/provider/profile_provider.dart';
import 'package:doctor_v2/provider/state_provider.dart';
import 'package:doctor_v2/provider/vital_sign_provider.dart';
import 'package:doctor_v2/views/welcome/welcome_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package/provider/form_provider.dart';
import 'provider/appointment_provider.dart';
import 'provider/consultation_provider.dart';
import 'provider/lab_test_provider.dart';
import 'provider/prescription_provider.dart';
import 'provider/schedule_provider.dart';
import 'views/login/login.dart';
import 'views/otp/otp_screen.dart';
import 'views/otp/widgets/not_approved.dart';
import 'views/verification/form_verification_provider.dart';
import 'views/verification/verification_provider.dart';
import 'views/verification/verification_view.dart';
import 'views/vital_sign/vital_sign.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  //runApp(MyApp());
  runApp(
      MultiProvider(
        providers: [
          //ChangeNotifierProvider(create: (context) => di.sl<ThemeProvider>()),
          ChangeNotifierProvider(create: (context) => AuthProvider()),
          ChangeNotifierProvider(create: (context) => ProfileProvider()),
          ChangeNotifierProvider(create: (context) => AppProvider()),
          ChangeNotifierProvider(create: (context) => StateProvider()),
          ChangeNotifierProvider(create: (context) => VitalSignProvider()),
          ChangeNotifierProvider(create: (context) => ConsultationProvider()),
          ChangeNotifierProvider(create: (context) => AppointmentProvider()),
          ChangeNotifierProvider(create: (context) => ScheduleProvider()),
          ChangeNotifierProvider(create: (context) => FormProvider()),

          ChangeNotifierProvider(create: (context) => VerificationProvider()),
          ChangeNotifierProvider(create: (context) => FormVerificationProvider()),
          ChangeNotifierProvider(create: (context) => PrescriptionProvider()),
          ChangeNotifierProvider(create: (context) => LabTestProvider()),
        ],
        child: MyApp(),
      )
  );
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SonoCare Doctors App',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: WelcomeScreen()//MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}