class Images {
  static const String scope = 'assets/logo/scope.png';
  static const String main_logo_sm = 'assets/logo/main_logo_sm.png';
  static const String main_logo = 'assets/logo/main_logo.png';
}
