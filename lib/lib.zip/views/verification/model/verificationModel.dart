class VerificationModel{
  bool verified = true;
  String message = '';
  VerificationModel({required this.verified, required this.message});
}