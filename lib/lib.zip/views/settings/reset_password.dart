import 'package:doctor_v2/utill/color_resources.dart';
import 'package:doctor_v2/views/shared/background.dart';
import 'package:doctor_v2/views/ui_kits/ui_kits.dart';
import 'package:flutter/material.dart';

class ResetPasswordScreen extends StatelessWidget {
  ResetPasswordScreen({Key? key}) : super(key: key);

  TextEditingController _otpController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();
  TextEditingController _passwordConfirmationController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Stack(children: [
      DarkBackGround(),
      Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            leading: GestureDetector(
                onTap: ()=>Navigator.pop(context),
                child: Image.asset('assets/icons/back-arrow_icon.png')),
            title: Text('Password', style: TextStyle(color: Colors.white),),
            elevation: 0,
          ),
          body: ListView(children: [
            SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: textField(obscureText: false, hintText: 'Enter your email', label:'Email', icon: Icon(Icons.mail_outline, color: Colors.white), controller: _emailController, validator: (){}, onChanged: (){}),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: textField(obscureText: false, hintText: 'Enter the Code sent to your phone', label:'OTP', icon: Icon(Icons.lock, color: Colors.white), controller: _otpController, validator: (){}, onChanged: (){}),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: textField(obscureText: true, hintText: 'Enter your Password', label:'Password', icon: Icon(Icons.lock, color: Colors.white), controller: _passwordController, validator: (){}, onChanged: (){}),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: textField(obscureText: true, hintText: 'Enter your Password again', label:'Confirm Password', icon: Icon(Icons.lock, color: Colors.white), controller: _passwordConfirmationController, validator: (){}, onChanged: (){}),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.all(18.0),
              child: Row(
                  children: [
                    Expanded(child: normalButton(
                        backgroundColor: ColorResources.COLOR_PURPLE_MID,
                        button_text: 'Reset Password',
                        primaryColor: ColorResources.COLOR_WHITE,
                        fontSize: 16,
                        onTap: (){}))]),
            )
          ]))
    ],);
  }
}
